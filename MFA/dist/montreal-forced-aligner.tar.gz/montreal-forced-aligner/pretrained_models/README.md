# mfa-models
Collection of pretrained models for the Montreal Forced Aligner
